<?php $__env->startSection('content'); ?>
    <?php if(auth()->guard()->guest()): ?>
        <welcome-component></welcome-component>
    <?php else: ?>
        <welcome-component user="<?php echo e(auth()->user()); ?>"></welcome-component>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\hermeshub\resources\views/welcome.blade.php ENDPATH**/ ?>